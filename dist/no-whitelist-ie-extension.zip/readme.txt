Install:
* Install Visual C++ runtime from https://www.microsoft.com/en-us/download/details.aspx?id=40784
* Set URL of the script you wish to load in the inJs.js file
* Close all instances of Internet Explorer
* Open command line in admin mode
* Navigate to inJs.dll location and execute:
	regsvr32.exe inJs.dll
* A popup message will appear notifying that the dll has been registered
* Run Internet Explorer and authorize new addon if prompted. Restarting Internet Explorer might be necessary

Uninstall:
* Close all instances of Internet Explorer
* Open command line in admin mode
* Navigate to inJs.dll location and execute:
	regsvr32.exe /u inJs.dll
* A popup message will appear notifying that the dll has been unregistered

HTTP Request Routing API:
	The BHO provides a very simple way to route HTTP requests in order to avoid cross-site sharing
	limitations.
	
	A couple of methods are exposed to javascript that will take the url and parameters of the request
	and execute it in the context of the BHO and return the response data to javascript.
	
	* GET requests: 
		Method: inJsBHO.getRequest(string url)
			This method handles GET requests.
		Params:
			- string url: A URL string
		Return:
			The request response is passed to javascript as a string in this global object: inJsBHOAPI.reqResponse
	* POST requests: 
		Method: inJsBHO.getRequest(string host, string action, string data)
			This method handles POST requests.
		Params:
			- string host: A URL string for the host. If we wanted to send a request to http://mysite.com/stuff/index.php
			we would set the host string as "mysite.com"
			- string action: The rest of the URL after the host string. For http://mysite.com/stuff/index.php
			we would set action to "stuff/index.php"
			- string data: The data to be sent along with the request. URL encoding
		Return:
			The request response is passed to javascript as a string in this global object: inJsBHOAPI.reqResponse
